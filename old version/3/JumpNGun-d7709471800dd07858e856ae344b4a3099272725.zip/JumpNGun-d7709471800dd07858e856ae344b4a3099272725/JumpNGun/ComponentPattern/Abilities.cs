﻿namespace JumpNGun
{
    public class Abilities : Component
    {
        
    }
}